from django.shortcuts import render,redirect
from .models import Post
from .forms import PostForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Post, Like
from django.shortcuts import render
from .models import Post
from django.views.decorators.csrf import csrf_exempt



@login_required
def home(request):
    posts = Post.objects.all()
    for post in posts:
        post.like_count = post.like_set.count()
    return render(request, 'posts/home.html', {'posts': posts})

def about(request): 
    # Temporary about view 
    return render(request, 'my_app/about.html') 

def contact(request): 
    # Temporary contact view 
    return render(request, 'my_app/contact.html')



User = get_user_model()

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Post
from .forms import PostForm

@login_required
def create_post(request):
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            post.like_count = 0  # Ensure like_count is set to 0
            post.comment_count = 0  # Ensure comment_count is set to 0
            post.save()
            return redirect('home')
    else:
        form = PostForm()
    return render(request, 'posts/create_post.html', {'form': form})




from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Post, Like
from django.shortcuts import get_object_or_404, redirect


from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect
from .models import Post, Like
from django.contrib.auth.decorators import login_required

@login_required
def like_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    like, created = Like.objects.get_or_create(user=request.user, post=post)
    
    if not created:
        like.delete()
        liked = False
    else:
        liked = True
    
    return JsonResponse({'liked': liked, 'like_count': post.like_set.count()})





# @login_required
# def add_comment(request, post_id):
#     post = Post.objects.get(id=post_id)
#     if request.method == 'POST':
#         comment_text = request.POST.get('comment_text')
#         comment = Comment(post=post, user=request.user, comment_text=comment_text)
#         comment.save()
#         return redirect('home')
#     return render(request, 'posts/post_detail.html', {'post': post})


# @csrf_exempt 
# def add_comment(request): 
#     if request.method == 'POST': 
#         post_id = request.POST.get('post_id') 
#         comment_text = request.POST.get('comment_text') 
#         post = get_object_or_404(Post, id=post_id) 
#         user_profile = get_object_or_404(UserProfile, user=request.user) 
#         comment = Comment(post=post, user=user_profile, comment_text=comment_text) 
#         comment.save() 
#         return JsonResponse({'username': comment.user.user.username, 'comment_text': comment.comment_text, 'profile_image': comment.user.profile_image.url}) 
#     return JsonResponse({'error': 'Invalid request'}, status=400)
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Post, Comment

def get_comments(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    comments = post.comment_set.all().values('user__username', 'comment_text')  # Fixed 'text' to 'comment_text'
    return JsonResponse({'comments': list(comments)})

def add_comment(request, post_id):
    if request.method == "POST":
        post = get_object_or_404(Post, id=post_id)
        Comment.objects.create(user=request.user, post=post, comment_text=request.POST["comment"])  # Fixed 'text' to 'comment_text'
        return JsonResponse({"message": "Comment added successfully!"})
