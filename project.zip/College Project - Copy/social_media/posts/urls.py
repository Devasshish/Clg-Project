from django.urls import path
from .views import home, create_post, like_post,about,contact,add_comment,get_comments

urlpatterns = [
    path('', home, name='home'),
    path('about/', about, name='about'), 
    path('contact/', contact, name='contact'),
    path('create/', create_post, name='create_post'),
    path('like/<int:post_id>/', like_post, name='like_post'),
    path('add_comment/<int:post_id>/', add_comment, name='add_comment'),
    path('comments/<int:post_id>/', get_comments, name='get_comments'),
]
